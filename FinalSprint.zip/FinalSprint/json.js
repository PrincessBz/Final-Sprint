fetch("./People.json")
  .then((response) => response.json())
  .then((People) => {
    console.log(People);

    // data Loop through an array in the JSON
    document.write(`<ul>`);
    People.forEach((person) => {
      document.write(` <li> Welcome ${person.fname} ${person.lname} ${person.gender} to our Inn. </li>`);
      console.log(getlname(person));
      console.log(getAge(person));
      console.log(getGender(person));
    });
    document.write(`</ul>`);
  })
  .catch((error) => {
    // Handle any errors that occur while fetching the file
    console.error(error);
  });

function getlname(person) {
  return person.lname;
}

function getAge(person) {
//   if (age <= 12) return 'Child';
//   else if (age > 12 && age <= 15) return 'Teen'
//   else return 'Mature'
     return person.age;
}

function getGender(person) {
  return person.gender;
}
